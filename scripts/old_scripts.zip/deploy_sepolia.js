// scripts/deploy.js
const { ethers } = require("hardhat");
require("dotenv").config();

async function main() {
  console.log("Starting deployment process...");
  console.log(`Network: ${network.name}`);

  // Get the signers
  const [deployer] = await ethers.getSigners();
  console.log(`Deploying contracts with the account: ${deployer.address}`);
  
  // Get the initial balance
  const initialBalance = await ethers.provider.getBalance(deployer.address);
  console.log(`Account balance: ${ethers.formatEther(initialBalance)} ETH`);

  try {
    // Deploy CustodianRegistry first
    console.log("Deploying CustodianRegistry...");
    const CustodianRegistry = await ethers.getContractFactory("CustodianRegistry");

    // --- MODIFIED LINE: Adjusted the gasLimit object ---
    const custodianRegistry = await CustodianRegistry.deploy(
      deployer.address, // Pass only the required initialAdmin argument
      { gasLimit: 300000 }

    );
    // -------------------------------------------------

    console.log("Waiting for CustodianRegistry deployment transaction to be mined...");
    await custodianRegistry.waitForDeployment();
    const custodianRegistryAddress = await custodianRegistry.getAddress();
    console.log(`CustodianRegistry deployed to: ${custodianRegistryAddress}`);


    // Deploy T3Token
    console.log("Deploying T3Token...");
    const T3Token = await ethers.getContractFactory("T3Token");
    const treasuryAddress = deployer.address; // Using deployer as treasury for demo
    const t3Token = await T3Token.deploy(
      deployer.address, 
      treasuryAddress,
      { gasLimit: 300000 }
    );
    console.log("Waiting for T3Token deployment transaction to be mined...");
    await t3Token.waitForDeployment();
    const t3TokenAddress = await t3Token.getAddress();
    console.log(`T3Token deployed to: ${t3TokenAddress}`);

    // Calculate gas used
    const finalBalance = await ethers.provider.getBalance(deployer.address);
    const gasUsed = initialBalance - finalBalance;
    console.log(`Gas used: ${ethers.formatEther(gasUsed)} ETH`);

    // Log deployment information
    console.log("\nDeployment Summary:");
    console.log("===================");
    console.log(`CustodianRegistry: ${custodianRegistryAddress}`);
    console.log(`T3Token: ${t3TokenAddress}`);
    console.log(`Deployer/Admin: ${deployer.address}`);
    console.log(`Treasury: ${treasuryAddress}`);
    
    // Update .env file with contract addresses
    console.log("\nUpdate your .env file with these values:");
    console.log(`CUSTODIAN_REGISTRY_ADDRESS=${custodianRegistryAddress}`);
    console.log(`T3_TOKEN_ADDRESS=${t3TokenAddress}`);
    
    return {
      custodianRegistryAddress,
      t3TokenAddress,
      deployerAddress: deployer.address,
      treasuryAddress
    };
  } catch (error) {
    console.error("Deployment failed with error:");
    console.error(error);
    throw error;
  }
}

// Execute the deployment
if (require.main === module) {
  main()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
}

module.exports = { main };
